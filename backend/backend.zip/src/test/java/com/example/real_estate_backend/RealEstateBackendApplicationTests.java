package com.example.real_estate_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealEstateBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
