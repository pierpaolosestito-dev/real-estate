import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { Subject, of } from 'rxjs';
import { switchMap, takeUntil, catchError } from 'rxjs/operators';

import { AnnouncementService } from '../../core/services/announcement.service';
import { Announcement } from '../../core/models/announcement.model';

@Component({
  selector: 'app-announcement-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './announcement-detail.html',
  styleUrls: ['./announcement-detail.css']
})
export class AnnouncementDetailComponent implements OnInit, OnDestroy {

  announcement: Announcement | null = null;
  loading = true;
  error = false;

  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private announcementService: AnnouncementService
  ) {}

  ngOnInit(): void {
    this.route.paramMap
      .pipe(
        takeUntil(this.destroy$),
        switchMap(params => {
          const id = Number(params.get('id'));

          if (!id) {
            this.error = true;
            this.loading = false;
            return of(null);
          }

          this.loading = true;
          this.error = false;
          this.announcement = null;

          return this.announcementService.getById(id).pipe(
            catchError(err => {
              console.error(err);
              this.error = true;
              return of(null);
            })
          );
        })
      )
      .subscribe(data => {
        this.announcement = data;
        this.loading = false;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  get mailtoLink(): string {
    const v = this.announcement?.venditore;
    if (!v?.email) return '';

    const subject = encodeURIComponent(
      `Richiesta informazioni: ${this.announcement?.titolo}`
    );

    const body = encodeURIComponent(
      `Buongiorno ${v.nome},\n\n` +
      `sono interessato all'annuncio "${this.announcement?.titolo}".\n` +
      `Potrei ricevere maggiori informazioni?\n\nGrazie.`
    );

    return `mailto:${v.email}?subject=${subject}&body=${body}`;
  }
}
