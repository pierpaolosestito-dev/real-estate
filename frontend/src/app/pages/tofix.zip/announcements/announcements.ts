import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AnnouncementService } from '../../core/services/announcement.service';
import { Announcement } from '../../core/models/announcement.model';

@Component({
  selector: 'app-announcements',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './announcements.html',
  styleUrls: ['./announcements.css']
})
export class AnnouncementsComponent implements OnInit {

  announcements: Announcement[] = [];

  // filtri UI
  filterTipo: string = '';
  filterPrezzo?: number;
  filterCitta: string = '';

  loading = true;
  error = false;

  constructor(private announcementService: AnnouncementService) {}

  ngOnInit(): void {
    this.announcementService.getAll().subscribe({
      next: data => {
        this.announcements = data;
        this.loading = false;
      },
      error: err => {
        console.error(err);
        this.error = true;
        this.loading = false;
      }
    });
  }

  get filteredAnnouncements(): Announcement[] {
    return this.announcements.filter(a =>
      (!this.filterTipo || a.tipo === this.filterTipo) &&
      (!this.filterPrezzo || a.prezzo <= this.filterPrezzo) &&
      (!this.filterCitta ||
        a.immobile?.location?.city?.toLowerCase().includes(this.filterCitta.toLowerCase()))
    );
  }
}
